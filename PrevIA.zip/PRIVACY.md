## Política de privacidad de PrevIA – Protege tus textos

Esta extensión no recopila, almacena ni comparte información personal.  
Todo el procesamiento de texto se realiza localmente en el navegador del usuario, sin conexión a Internet.  
No se transmiten datos a servidores externos ni se usan cookies ni identificadores.  

Desarrollado por Sara Cubero García-Conde · 2025

import { bindEvents } from './events.js';
bindEvents();
